﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;



namespace FinalVickyPatel
{
    /// <summary>
    /// Interaction logic for AddContinent.xaml
    /// </summary>
    public partial class AddContinent : Window
    {
        public AddContinent()
        {
            InitializeComponent();
        }

        public Boolean checkValidation()
        {
            if (txtBoxContnamecont.Text.ToString().Trim().Length == 0)
            {
                lblErrorFldcont.Content = "Must Required";
                return false;
            }

            return true;
        }

        private void btnCloseCont_Click(object sender, RoutedEventArgs e)
        {
            txtBoxContnamecont.Clear();
            Close();
        }

        private void btnAddCont_Click(object sender, RoutedEventArgs e)
        {
            if (checkValidation())
            {
                using (var context = new WorldDBFinalEntities())
                {
                    var name = new Continent();
                    name.ContinentName = txtBoxContnamecont.Text;
                    context.Continents.Add(name);
                    context.SaveChanges();
                    txtBoxContnamecont.Clear();
                    MessageBox.Show("Continet added Succesfully");
                    

                }
            }
        }
    }
}
    
