﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;



namespace FinalVickyPatel
{
    /// <summary>
    /// Interaction logic for HomeWindow.xaml
    /// </summary>
    public partial class HomeWindow : Window
    {
        public HomeWindow()
        {
            InitializeComponent();
           
        }

        private void btnAddContHome_Click(object sender, RoutedEventArgs e)
        {
            Window one = new AddContinent();
            one.Show();
            

        }

        private void btnAddCountHome_Click(object sender, RoutedEventArgs e)
        {
            Window one = new AddCountry();
            one.Show();
            
        }

        private void btnAddCityHome_Click(object sender, RoutedEventArgs e)
        {
            Window one = new AddCity();
            one.Show();
           
        }
      
        public void loadConinent()
        {
            using (var context = new WorldDBFinalEntities())
            {


              var data = context.Continents.ToList();
              cmbBoxHome1.ItemsSource = data;
              cmbBoxHome1.DisplayMemberPath = "ContinentName";
              cmbBoxHome1.SelectedValuePath = "ContinentId";
                  
            }

           
        }

        public void loadCountriesUsingId(int id)
        {
            using (var context = new WorldDBFinalEntities())
            {
                var query = (from a in context.Countries
                             where a.ContinentId == id
                             select new { a.CountryName, a.CountryId }).ToList();

                lstBoxHome.ItemsSource = query;
                lstBoxHome.DisplayMemberPath = "CountryName";
                lstBoxHome.SelectedValuePath = "CountryId";
            }


        }

        public void loadCityUsingId(int id)
        {

            using (var context = new WorldDBFinalEntities())
            {
                var query = (from a in context.Cities
                             where a.CountryId == id
                             select new { a.CityId, a.CityName, a.IsCapital,a.Population,a.CountryId}).ToList();

                datagrdHome.ItemsSource = query;
                

            }



        }

        public void getLanguageandCurrencyUsingId(int id)
        {
            using (var context = new WorldDBFinalEntities())
            {
                var Query = (from a in context.Countries
                             where a.CountryId == id
                             select new { a.Language, a.Currency}).ToList();

                foreach (var item in Query)
                {
                    lblDispLangHome.Content = item.Language;
                    lbldsplCurHome.Content = item.Currency;
                    
                }




            }


        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            loadConinent();

        }

        private void cmbBoxHome1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox item = sender as ComboBox;
            int id = Int32.Parse(item.SelectedValue.ToString());
            loadCountriesUsingId(id);
        }

        private void lstBoxHome_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBox item = sender as ListBox;
            int id = Int32.Parse(item.SelectedValue.ToString());
            getLanguageandCurrencyUsingId(id);
            loadCityUsingId(id);
        }
    }
}
