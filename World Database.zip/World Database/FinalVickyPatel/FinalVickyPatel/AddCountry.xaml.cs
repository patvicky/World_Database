﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace FinalVickyPatel
{
    /// <summary>
    /// Interaction logic for AddCountry.xaml
    /// </summary>
    public partial class AddCountry : Window
    {
        int continentId;
        public AddCountry()
        {
            InitializeComponent();
            loadContinent();
        }

        public void loadContinent()
        {
            using (var context = new WorldDBFinalEntities())
            {


                var data = context.Continents.ToList();
                cmbBoxCountry.ItemsSource = data;
                cmbBoxCountry.DisplayMemberPath = "ContinentName";
                cmbBoxCountry.SelectedValuePath = "ContinentId";

            }

        }

        private Boolean checkValidation()
        {
            if (cmbBoxCountry.SelectedItem == null)
            {
                lblerrorReq1Count.Content = "Must Required";
                //lblerrorReq2Count.Content =  "Must Required";
                return false;
            }


            else if (txtBoxCountryNameCount.Text.ToString().Trim().Length == 0)
            {
                lblerrorReq2Count.Content = "Must Required";
                return false;

            }

            
            return true;
        }

        private void btnAddCountryWnd_Click(object sender, RoutedEventArgs e)
        {

            addCountryUsingId(continentId);
            txtBoxCountryNameCount.Clear();
            txtBoxCurrencyCount.Clear();
            txtBoxLanguageCount.Clear();


        }

        private void btnCloseCountryWnd_Click(object sender, RoutedEventArgs e)
        {
            txtBoxCountryNameCount.Clear();
            txtBoxCurrencyCount.Clear();
            txtBoxLanguageCount.Clear();
            Close();
        }

        private void cmbBoxCountry_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox item = sender as ComboBox;
            int id = Int32.Parse(item.SelectedValue.ToString());
            continentId = id;
        }

        public void addCountryUsingId(int id)
        {
            if (checkValidation())
            {

                using (var context = new WorldDBFinalEntities())
                {
                    var name = new Country();
                    name.ContinentId = id;
                    name.CountryName = txtBoxCountryNameCount.Text;
                    name.Language = txtBoxLanguageCount.Text;
                    name.Currency = txtBoxCurrencyCount.Text;
                    context.Countries.Add(name);
                    context.SaveChanges();

                    MessageBox.Show("County added Succesfully");
                }


            }


        }
    }
}
