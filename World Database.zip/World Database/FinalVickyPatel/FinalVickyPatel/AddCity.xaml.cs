﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;



namespace FinalVickyPatel
{
    /// <summary>
    /// Interaction logic for AddCity.xaml
    /// </summary>
    public partial class AddCity : Window
    {
        int countryId;
        public AddCity()
        {
            InitializeComponent();
            loadCity();
        }

        public void loadCity()
        {
            using (var context = new WorldDBFinalEntities())
            {


                var data = context.Countries.ToList();
                cmbBoxCountryNameCityWnd.ItemsSource = data;
                cmbBoxCountryNameCityWnd.DisplayMemberPath = "CountryName";
                cmbBoxCountryNameCityWnd.SelectedValuePath = "CountryId";

            }


        }


        private Boolean checkValidation()
        {
            if (cmbBoxCountryNameCityWnd.SelectedItem == null)
            {

                lblerrorReq1City.Content = "Must Required";
                return false;
            }


            else if (txtBoxCityNameCityWnd.Text.ToString().Trim().Length == 0)
            {
                lblerrorReq2City.Content = "Must Required";
                return false;

            }

            return true;
        }

        private void btnAddCityWnd_Click(object sender, RoutedEventArgs e)
        {
            addCityUsingId(countryId);
            txtBoxCityNameCityWnd.Clear();
            txtBoxPopulationCity.Clear();

        }

        private void btnCloseCityWnd_Click(object sender, RoutedEventArgs e)
        {
            txtBoxCityNameCityWnd.Clear();
            txtBoxPopulationCity.Clear();
            Close();
        }


        private void cmbBoxCountryNameCityWnd_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox item = sender as ComboBox;
            int id = Int32.Parse(item.SelectedValue.ToString());
            countryId = id;
        }

        public void addCityUsingId(int id)
        {
            if (checkValidation())
            {
                using (var context = new WorldDBFinalEntities())
                {

                    var city = new City();
                    city.CountryId = id;
                    city.CityName = txtBoxCityNameCityWnd.Text;
                    city.Population = txtBoxPopulationCity.Text;

                    if (chkbxCity.IsChecked == true)
                    {
                        city.IsCapital = true;
                    }
                    else
                    {
                        city.IsCapital = false;

                    }

                    context.Cities.Add(city);
                    context.SaveChanges();

                    MessageBox.Show("City added Succesfully");

                }

            }
           

        }
    }
}
